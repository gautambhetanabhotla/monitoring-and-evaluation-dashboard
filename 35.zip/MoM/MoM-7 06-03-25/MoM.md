communication through whatsapp : 

-> meeting shifted to saturday
 
-> clarification on charts movability

  -> two types

  -> changing the orders of graphs

        ->grid system

  -> free movement of the charts

        ->co-ordinate system