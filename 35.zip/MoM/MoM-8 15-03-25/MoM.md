## MoM 
### Communication through Whatsapp :
-> No meeting This Week

- The visulaization in the project page
  
  - Can be able to link with KPI
  
  - Independent of KPI with File uploading
  
  
- Demo on KPI Update
  
  - The update (you will be able to choose which KPI to update and by how much)
  

No of CLients and handling Capacity for WEB Page :

- There will be 4-5 Clients at any given point of time for now. This may increase in the coming year.

