## Meet 2, Feb 3 2025

- Someone would want to see the status of, say, the project in the current quarter compared to the project status in the last quarter. Try to implement
- how many projects completed on time?
- average budgets?
- how many on time? delayed? (kinda redundant)
- LOTS of data visualization. For each numerical metric, have the user be able to select what the mode of displaying that data should be. Either a bar chart, or pie chart, etc.
- Need a feature to block a client's view access from project.