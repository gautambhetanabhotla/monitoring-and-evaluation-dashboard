2nd Client meet
- Dudamistry College, Opposite to <Could not hear location> : Teach students of Social Work (50+ yrs)
- Status? Finalizing the UI. Sort of a structure in place+ road map in place
- Key takeaways from M&E Dashboards: Openness to the platform, so that it can be used by other agents instead of building from scratch.
Overviews, metrics of evaluation, budgets allocated, divided into tasks, they can comment on a particular task in project as well, feedback mechanism
Eg: 6 RO plants in 5 villages, status of all the projects in this state and in this quarter, single glance of all projects in dashboard; Client should be able to see the quarterly as well as monthly updates, single glance picture, now he agent can filter through deeper details related to specific reports+ comparative study amongst certain related projects as well, er all
- Reports show infographia, status of particular projects all in the page just as agent enters the dashboard: All numbers at a glance for all projects, Data visualisation different options to admins and client users
- Ppt form of reports: All the sites they have worked at, number of communities at each place, bar graph, list of all the programs in all the trust areas they work in, which project which site, and all the programs should be there: 1st page: cumulative+ as they click on it, specific pages from the cumulative page, and in the cumulative + specific page, client should be able to decide how to display infographia, like bar graph or histogram etc.
- Login, authentication mechanism on a client- by client basis.+ Temporary credentials particular number to valid days
- Using the database, specifications, load of db, get dbs from google, microsoft, or amazon. (Hosting the db)
- Log framework supposed to be given
- Users: Admin team and the client. Only those two logins, admin control access, access of projects to be decided by admin (Anusandhan)
- Confidentiality of client programs, non-disclosure agreement, client only sees project of theirs
- 2 main releases: 1st get the platform ready, populate it with dummy clients data dynamically, the real data
- Recurring calls: Once a week, Wednesday or Saturday
- Field visits this week. Survey, how many people participated in survey, how many hostels surveyed, presented as report to clients+ cumulative page
- Questions of proxy indication: Bugets allocated, used, timelines, giving options of inputting data to admin for each project, open options in building it up
- In one week, how many hostels were covered, stacked bar chart, target, accomplished, option, do admin want to show a bar graph, a pie chart, or histogram, leaving the choice to admin