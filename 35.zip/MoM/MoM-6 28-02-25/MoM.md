communication through whatsap 

- no meeting due to mid exams

- doubts about log framework

- provided a sample log framework for reference.

